
package TestSide;

import AppSide.Login;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    private final String SUCCESS_OUTPUT = "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";

    @Test
    public void testUsernameIsCorrectlyFormatted() {
        Login testLogin = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(SUCCESS_OUTPUT, testLogin.registerUser());
    }

    @Test
    public void testUsernameIsIncorrectlyFormatted() {
        Login testLogin = new Login("Kyle", "Smith", "wrong", "Ch&&sec@ke99!", "+27838968976");
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.", testLogin.registerUser());
    }

    @Test
    public void testPasswordMeetsComplexityRequirements() {
        Login testLogin = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(SUCCESS_OUTPUT, testLogin.registerUser());
    }

    @Test
    public void testPasswordDoesNotMeetComplexityRequirements() {
        Login testLogin = new Login("Kyle", "Smith", "kyl_1", "wrong", "+27838968976");
        assertEquals("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", testLogin.registerUser());
    }

    @Test
    public void testCellPhoneNumberCorrectlyFormatted() {
        Login testLogin = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(SUCCESS_OUTPUT, testLogin.registerUser());
    }

    @Test
    public void testCellPhoneNumberIncorrectlyFormatted() {
        Login testLogin = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "wrong");
        assertEquals("Cell phone number incorrectly formatted or does not contain international code.", testLogin.registerUser());
    }

    @Test
    public void testLoginSuccessful() {
        Login testLogin = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(testLogin.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginFailed() {
        Login testLogin = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertFalse(testLogin.loginUser("wrong", "wrong"));
    }

    @Test
    public void testUsernameCorrectlyFormattedBoolean() {
        Login testLogin = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(testLogin.checkUserName());
    }

    @Test
    public void testUsernameIncorrectlyFormattedBoolean() {
        Login testLogin = new Login("Kyle", "Smith", "wrong", "Ch&&sec@ke99!", "+27838968976");
        assertFalse(testLogin.checkUserName());
    }

    @Test
    public void testPasswordMeetsComplexityRequirementsBoolean() {
        Login testLogin = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(testLogin.checkPasswordComplexity());
    }

    @Test
    public void testPasswordDoesNotMeetComplexityRequirementsBoolean() {
        Login testLogin = new Login("Kyle", "Smith", "kyl_1", "wrong", "+27838968976");
        assertFalse(testLogin.checkPasswordComplexity());
    }

    @Test
    public void testCellPhoneNumberCorrectlyFormattedBoolean() {
        Login testLogin = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(testLogin.checkCellPhoneNumber());
    }

    @Test
    public void testCellPhoneNumberIncorrectlyFormattedBoolean() {
        Login testLogin = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "wrong");
        assertFalse(testLogin.checkCellPhoneNumber());
    }
}