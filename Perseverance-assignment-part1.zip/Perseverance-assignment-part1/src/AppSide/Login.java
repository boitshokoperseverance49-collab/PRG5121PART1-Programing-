
package AppSide;

/**
 * Login class - Final version for Part 1 assignment.
 * Implements all required validation and authentication methods.
 */
public class Login {
    
    private String firstNameStored;
    private String lastNameStored;
    private String userNameStored;
    private String passwordStored;
    private String phoneStored;

    public Login(String firstNameStored, String lastNameStored, String userNameStored, String passwordStored, String phoneStored) {
        this.firstNameStored = firstNameStored;
        this.lastNameStored = lastNameStored;
        this.userNameStored = userNameStored;
        this.passwordStored = passwordStored;
        this.phoneStored = phoneStored;
    }

    public boolean checkUserName() {
        return userNameStored.contains("_") && userNameStored.length() <= 5;
    }

    public boolean checkPasswordComplexity() {
        boolean upperCasePresent = false;
        boolean digitPresent = false;
        boolean specialCharPresent = false;

        if (passwordStored.length() < 8) {
            return false;
        }

        for (int position = 0; position < passwordStored.length(); position++) {
            char currentChar = passwordStored.charAt(position);
            
            if (Character.isUpperCase(currentChar)) upperCasePresent = true;
            if (Character.isDigit(currentChar)) digitPresent = true;
            if (!Character.isLetterOrDigit(currentChar)) specialCharPresent = true;
        }

        return upperCasePresent && digitPresent && specialCharPresent;
    }

    public boolean checkCellPhoneNumber() {
        return phoneStored.matches("^\\+27\\d{9}$");
    }

    public String registerUser() {
        if (this.checkUserName() == false) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (this.checkPasswordComplexity() == false) {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (this.checkCellPhoneNumber() == false) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }

    public boolean loginUser(String loginUserName, String loginPassword) {
        return userNameStored.equals(loginUserName) && passwordStored.equals(loginPassword);
    }

    public String returnLoginStatus(String loginUserName, String loginPassword) {
        boolean isLoggedIn = this.loginUser(loginUserName, loginPassword);
        return isLoggedIn ? "Welcome " + firstNameStored + ", " + lastNameStored + " it is great to see you again." : "Username or password incorrect, please try again.";
    }
}