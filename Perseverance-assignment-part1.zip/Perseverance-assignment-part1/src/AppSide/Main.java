
package AppSide;

import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        Scanner userInput = new Scanner(System.in);

        System.out.println("===== REGISTRATION =====");

        System.out.print("Enter first name: ");
        String first = userInput.nextLine();

        System.out.print("Enter last name: ");
        String last = userInput.nextLine();

        System.out.print("Enter username: ");
        String username = userInput.nextLine();

        System.out.print("Enter password: ");
        String password = userInput.nextLine();

        System.out.print("Enter South African cell phone number (include +27): ");
        String phone = userInput.nextLine();

        Login userAccount = new Login(first, last, username, password, phone);

        System.out.println(userAccount.registerUser());

        if (userAccount.checkUserName() && userAccount.checkPasswordComplexity() && userAccount.checkCellPhoneNumber()) {
            System.out.println();
            System.out.println("===== LOGIN =====");

            System.out.print("Enter username: ");
            String loginUser = userInput.nextLine();

            System.out.print("Enter password: ");
            String loginPass = userInput.nextLine();

            System.out.println(userAccount.returnLoginStatus(loginUser, loginPass));
        }

        userInput.close();
    }
}